v. 1.1 2020-10-27

                       :-) Zebra3D (-:
      
      A tool for systematic analysis of 3D-structural diversity 
            and specificity in protein superfamilies                

Documentation
=============

The latest version of the program, documentation and examples are available open-access at https://biokinet.belozersky.msu.ru/Zebra3D

INSTALLATION
============

Zebra3D is a Python3 command-line tool. Installation should be simple. 
Try running the following commands: 

pip install --upgrade pip
pip install -r requirements.txt
python3 ./Zebra3D.py

Something went wrong? See the overview of the installation procedure in more details at https://biokinet.belozersky.msu.ru/Zebra3D-installation

Also, don't forget to install PyMol Molecular Graphics System. It is used by Zebra3D to compile 3D-annotations - a convenient way to store and study the results. If you do not have PyMol installed and do not want it installed, you can run Zebra3D with the "-compile_pymol_pse=false" switch to produce only plain-text-based output.

EXECUTION
=========

python3 /path/to/Zebra3D.py aligned_pdbs=</path/to/folder> aligned_fasta=</path/to/file> output=</path/to/folder> [options]

For the complete list of options/parameters, visit https://biokinet.belozersky.msu.ru/Zebra3D-parameters, 
or run:

python3 /path/to/Zebra3D.py

EXAMPLE
=======

#Enter sub-folder with the example data

cd Example_03_HAR

#Execute Zebra3D with default settings, but remove SSRs with N-/C-terminal regions for clarity at this time

python3 ../Zebra3D.py aligned_pdbs=./aligned_pdbs/ aligned_fasta=strcore_A-z1w7c3azfsyp7g.fasta output=results exclude_ncterm=5

#Wait for the program to complete the analysis. Execution of this task takes 4 minutes on 8-core Intel Core i9-9900KF CPU @ 3.60GHz

#Enter sub-sub-folder with results

cd results/

#View the results summary, see the on-line manual for details available at https://biokinet.belozersky.msu.ru/Zebra3D-output#summary

cat RESULTS.txt

#Now open the 3D-annotation of the SSR #1 (the "best" region, according to the Zebra3D's scoring assessment) in PyMol Molecular Graphics System (has to be installed separatelly from Zebra3D). See the on-line manual for details available at https://biokinet.belozersky.msu.ru/Zebra3D-output#ssr

pymol ssr_001.pse

PREPARATION OF THE INPUT
========================

The input to Zebra3D can be prepared automatically using the Mustguseal web-server. See this on-line tutorial - https://biokinet.belozersky.msu.ru/Zebra3D-input.

QUESTIONS AND COMMENTS
======================

Still have questions? Don't hessitate to send us an e-mail at d.a.suplatov@belozersky.msu.ru




