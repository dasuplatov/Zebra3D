#    Zebra3D: Tool for bioinformatic analysis of 3D-determinants of functional diversity in protein superfamilies
#    Copyright (C) 2020-2021 Timonina D., Sharapova Y., Švedas V., Suplatov D.
#    "Dmitry Suplatov" <d.a.suplatov@belozersky.msu.ru>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

def names_of_prot(fasta):
    fassta = fasta.read().split(">")
    names_of_prot = []
    k = 0
    for i in fassta:
        arr = i.split('\n')
        names_of_prot.append(arr[0])
        arr[0] = ''
        fassta[k] = ''
        for n in arr:
            fassta[k] += n
        k += 1
    del fassta[0]
    del names_of_prot[0]
    fasta.seek(0)
    return names_of_prot
  
def seq_from_fasta(fasta):
    fassta = fasta.read().split(">")
    k = 0
    for i in fassta:
        arr = i.split('\n')
        arr[0] = ''
        fassta[k] = ''
        for n in arr:
            fassta[k] += n
        k += 1
    del fassta[0]
    fasta.seek(0)
    return fassta



