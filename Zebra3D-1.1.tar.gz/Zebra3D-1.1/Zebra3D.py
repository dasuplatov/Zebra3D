#    Zebra3D: Tool for bioinformatic analysis of 3D-determinants of functional diversity in protein superfamilies
#    Copyright (C) 2020-2021 Timonina D., Sharapova Y., Švedas V., Suplatov D.
#    "Dmitry Suplatov" <d.a.suplatov@belozersky.msu.ru>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import numpy as np
import math
from optics import *
import par_to_al
import copy
import clust_to_pdb
from knee import *
import multiprocessing
from multiprocessing import Pool
import sys
import os.path 
from progress.bar import IncrementalBar
import datetime
import scipy.stats

perс_of_gaps = 0.05
v = 1.1
d = "2020-Oct-27"

def pdbflex_extract(path_to_program):
    pdbflex_sils = []
    pdbflex_diams = []
    for i in range(0,100):
        if 'PDBFLEX_{}_sil.txt'.format(i) in os.listdir(os.path.join(os.path.join(path_to_program, 'PDBFlex'))):
            with open(os.path.join(os.path.join(path_to_program, 'PDBFlex'), 'PDBFLEX_{}_sil.txt'.format(i)), 'rb') as f:
                pdbflex_sils.append(np.loadtxt(f))
            with open(os.path.join(os.path.join(path_to_program, 'PDBFlex'), 'PDBFLEX_{}_diam.txt'.format(i)), 'rb') as f:
                pdbflex_diams.append(np.loadtxt(f))
    return pdbflex_sils, pdbflex_diams


def printing_input_info(dict_of_sys_argv, ref_protein, method_of_clustering, eps_for_clustering, perс_of_gaps, min_size_of_subfamily, max_outliers, create_pse, max_ssr_length, max_content_of_mismatch, exclude_ncterm, cpu_threads):

    print('\nInput: Running Zebra3D in {} parallel CPU thread(s)'.format(cpu_threads))
    print('Input: Path to aligned protein 3D-structures in PDB format is {}'.format(os.path.abspath(dict_of_sys_argv['aligned_pdbs'])))
    print('Input: Path to sequence representation of 3D-structural alignment in FASTA format is {}'.format(os.path.abspath(dict_of_sys_argv['aligned_fasta'])))
    print('Input: The reference protein is {}'.format(ref_protein))
    
    if method_of_clustering == 'dbscan': 
        print('Input: Cluster analysis method is {},'.format(method_of_clustering), 'eps = {}'.format(eps_for_clustering))
    else:
        print('Input: Cluster analysis method is {}'.format(method_of_clustering))    
    
    print('Input: Min size of a subfamily in SSR is {}'.format(min_size_of_subfamily))
    if 'ssr_start' in dict_of_sys_argv and 'ssr_end' in dict_of_sys_argv:
        print('Input: The selected SSR boundaries are [{};{}]'.format(dict_of_sys_argv['ssr_start'],dict_of_sys_argv['ssr_end']))
    else:
        print('Input: Max content of gaps in alignment column is {}%'.format(perс_of_gaps*100))
        print ('Input: Max content of mismatch in alignment column is {}%'.format(max_content_of_mismatch*100))
        if 'mismatch_threshold' in dict_of_sys_argv:
            print('Input: Cut-off value to discriminate spatially aligned from misaligned residues is {} A'.format(dict_of_sys_argv['mismatch_threshold']))
        print('Input: Max amount of outliers in SSR is {}%'.format(max_outliers*100))
        print('Input: Max average length within subfamily in SSR is {} amino acids'.format(max_ssr_length))
        if exclude_ncterm != -1:
            print('Input: Dismiss SSRs that assign N-/C-terminal regions (first and last {} residues of any PDB entry) to subfamilies'.format(exclude_ncterm))

    print('Input: Path to output folder is {}'.format(os.path.abspath(dict_of_sys_argv['output'])))

    if create_pse:
        print('Input: Compile PyMol PSE session files YES\n')
    else:
        print('Input: Compile PyMol PSE session files NO\n')

    return

def get_heaps_if_ssr_start_and_ssr_end(ref_protein, dirs, align, ssr_start, ssr_end):
    index_of_ref_protein = dirs.index(ref_protein)
    align_of_ref_protein = align[index_of_ref_protein]
    
    try:
        heap1 = align_of_ref_protein.index(ssr_start)-1
        heap2 = align_of_ref_protein.index(ssr_end)+1
    except Exception:
        raise Exception('Error: No ssr_start or ssr_end in reference protein')        
    
    return [[heap1,heap2]]
    
def aligned_pdb_folder_check(aligned_pdb_folder):
    for file in os.listdir(aligned_pdb_folder):
        if not file.endswith('.pdb'): raise Exception('Error: All files in '+aligned_pdb_folder+' should be .pdb')

def wrapped_align_improvement(args): 
    return par_to_al.align_improvement(*args) 

def wrapped_align_for_cut(args):
    return par_to_al.align_for_cut(*args) 

def n_c_not_exclude(res, flag, exclude_ncterm, n_term, c_term, len_heaps_ready):
    if exclude_ncterm == -1:
        return True

    if flag == 0 and n_term:
         return res.num_aa_in_longest_prot < exclude_ncterm

    if flag == len_heaps_ready - 1 and c_term:
        return res.num_aa_in_longest_prot < exclude_ncterm

    return True
    
def print_number_or_na(arg):
    if arg != -99999:
        return arg
    return 'N/A'

def printing(aligned_pdb_folder, results, rating_of_cl, cols, create_pse, output_folder, ref_protein):
   
    flag = 1
    bar = IncrementalBar('Info: Compiling PyMol PSE session files:', max=len(rating_of_cl[0]))
    for i, val in enumerate(rating_of_cl[0]):
        bar.next()
        if len(results[val].intact) == 0: continue
        clust_to_pdb.clust_to_pse(aligned_pdb_folder, flag, results[val].dirrss, results[val].lab, cols[val], results[val].intact, results[val].nothing, output_folder, ref_protein)
        if create_pse:
            os.system('pymol -qc '+os.path.join(output_folder, 'ssr_'+'{0:03}'.format(flag)+'.py'))
        f = open(os.path.join(output_folder, 'ssr_'+'{0:03}'.format(flag)+'.txt'), 'w')
        f.write('Z-score = {}\n'.format(print_number_or_na(round(rating_of_cl[1][val],3))))
        
        if rating_of_cl[6][val] != -99999:
            f.write('P-value = {:e}\n'.format(rating_of_cl[6][val]))
        else: 
            f.write('P-value = N/A\n')   
        f.write('S-score = {}\n'.format(print_number_or_na(round(rating_of_cl[7][val], 3))))
        f.write('Silhouette_score-raw = {}\n'.format(print_number_or_na(round(rating_of_cl[2][val],3))))
        f.write('Silhouette_score-std = {}\n'.format(print_number_or_na(round(rating_of_cl[4][val], 3))))
        f.write('Diameter-raw = {}\n'.format(print_number_or_na(round(rating_of_cl[3][val],3))))
        f.write('Diameter-std = {}\n'.format(print_number_or_na(round(rating_of_cl[5][val], 3))))
        f.write('Subfamily ID     Reference     Protein                         List of residues in SSR (numbering as in the PDB entry)\n')
        sorted_results = sorted(range(len(results[val].intact)), key=lambda k: results[val].lab[k] if results[val].lab[k] > -1 else sys.maxsize)
        
        for k in sorted_results:
            if results[val].dirrss[k] == ref_protein:
                mark = '*'
            else:
                mark = ' '

            if results[val].lab[k] == -1:
                f.write('Outlier' + ' '*14 + mark + ' '*9 + str(results[val].dirrss[k])[0:25] + ' '*(32-len(str(results[val].dirrss[k])[0:25])) + str(cols[val][results[val].intact[k]])+'\n')
            else:
                f.write(str(results[val].lab[k]+1) + ' '*(21-len(str(results[val].lab[k]))) + mark + ' '*9  + str(results[val].dirrss[k])[0:25] + ' '*(32-len(str(results[val].dirrss[k])[0:25])) + str(cols[val][results[val].intact[k]])+'\n')

        for k, vall in enumerate(results[val].nothing):
            if vall == ref_protein:
                mark = '*'
            else:
                mark = ' '
            f.write('Null_data' + ' '*12 + mark + ' '*9 + vall + ' '*(32-len(vall)) + 'No amino acids'+'\n')
        
        f.close()
        
        f = open(os.path.join(output_folder, 'ssr_'+'{0:03}'.format(flag)+'.fasta'),'w')
        
        for k in results[val].align_of_site:
            f.write(str(k)+'\n')
        f.close()
        flag += 1
    bar.finish()

def printing_warnings_skipped_no_diversity(ssrs, ref_protein):
    for ssr in ssrs:
        if ref_protein not in ssr[0].nothing:
            index_of_ref_protein = ssr[0].dirrss.index(ref_protein)
            print('Warning: Region of 3D-alignment that includes residues {}-{} in the reference protein has been rejected for lack of valid subfamilies'.format(ssr[1][ssr[0].intact[index_of_ref_protein]][0], ssr[1][ssr[0].intact[index_of_ref_protein]][-1]))

def printing_warnings_skipped_ssr_many_outliers(ssrs, ref_protein):
    for ssr in ssrs:
        if ref_protein not in ssr[0].nothing:
            index_of_ref_protein = ssr[0].dirrss.index(ref_protein)
            print('Warning: Region of 3D-alignment that includes residues {}-{} in the reference protein has been dismissed. To evaluate this region as potential SSR set the max_outliers to at least {}'.format(ssr[1][ssr[0].intact[index_of_ref_protein]][0], ssr[1][ssr[0].intact[index_of_ref_protein]][-1], math.ceil(ssr[0].perc_of_out*100)))

def printing_warnings_skipped_ssr_long_subf(ssrs, ref_protein):
    for ssr in ssrs:
        if ref_protein not in ssr[0].nothing:
            index_of_ref_protein = ssr[0].dirrss.index(ref_protein)
            print('Warning: Region of 3D-alignment that includes residues {}-{} in the reference protein has been dismissed. To evaluate this region as potential SSR set the max_ssr_length to at least {}'.format(ssr[1][ssr[0].intact[index_of_ref_protein]][0], ssr[1][ssr[0].intact[index_of_ref_protein]][-1], math.ceil(ssr[0].max_ssr_length)))

def printing_results(dirs, aligned_pdb_folder, aligned_fasta, results, rating_of_cl, cols, output_folder, time_start, ref_protein, ref_protein_in_fasta, dict_of_sys_argv, method_of_clustering, eps_for_clustering, perс_of_gaps, min_size_of_subfamily, max_outliers, create_pse, max_ssr_length, min_core_positions, exclude_ncterm):
    
    f = open(os.path.join(output_folder, 'RESULTS.txt'), 'w')
    f.write('Zebra3D. Version {}\n'.format(v))
    f.write('Started at '+ str(time_start).split('.')[0] +'\n\n')
    f.write('INPUT:\n')
    f.write('Path to aligned protein 3D-structures in PDB format is '+aligned_pdb_folder+'\n')
    f.write('Path to sequence representation of 3D-structural alignment in FASTA format is '+aligned_fasta+'\n')
    f.write('Path to output folder is {}\n'.format(os.path.abspath(dict_of_sys_argv['output'])))
    f.write('Number of analyzed proteins is '+str(len(dirs))+'\n')
    f.write('The reference protein is ' + ref_protein_in_fasta +'\n')
    
    if method_of_clustering == 'dbscan': 
        f.write('Cluster analysis method is {}, '.format(method_of_clustering) + 'eps = {}\n'.format(eps_for_clustering))
    else:
        f.write('Cluster analysis method is {}\n'.format(method_of_clustering))    
    
    if 'ssr_start' in dict_of_sys_argv and 'ssr_end' in dict_of_sys_argv:
        f.write('The selected SSR boundaries are [{};{}]\n'.format(dict_of_sys_argv['ssr_start'],dict_of_sys_argv['ssr_end']))
    else:
        f.write('Max content of gaps in alignment column is {}%\n'.format(perс_of_gaps*100))
        f.write('Max amount of outliers in SSR is {}%\n'.format(max_outliers*100))
        f.write('Max average length within subfamily in SSR is {} amino acids\n'.format(max_ssr_length))
        f.write('Max content of mismatch in alignment column is {}%\n'.format(min_core_positions*100))
        if 'mismatch_threshold' in dict_of_sys_argv:
            f.write('Cut-off value to discriminate spatially aligned from misaligned residues is {} A\n'.format(dict_of_sys_argv['mismatch_threshold']))
    f.write('Min size of a subfamily in SSR is {}\n'.format(min_size_of_subfamily))

    if exclude_ncterm != -1 and 'ssr_start' not in dict_of_sys_argv:
        f.write('Dismiss SSRs that assign N-/C-terminal regions (first and last {} residues of any PDB entry) to subfamilies\n'.format(exclude_ncterm))

    if create_pse:
        f.write('Compile PyMol PSE session files YES\n\n')
    else:
        f.write('Compile PyMol PSE session files NO\n\n')
    
    f.write('Number of SSR = '+str(len(rating_of_cl[0]))+'\n\n')
    f.write('SSR Rank      # of subfamilies      # of outliers      S-score      Z-score      P-value           SSR boundaries (residue numbering as in reference protein PDB)\n')
    
    for i, val in enumerate(rating_of_cl[0]):
        f.write(str(i+1) + ' '*(14-len(str(i+1))) + str(results[val].num_of_subf) + ' '*(22-len(str(results[val].num_of_subf))) + str(results[val].num_of_outliers) + ' '*(19-len(str(results[val].num_of_outliers))) + str(print_number_or_na(round(rating_of_cl[7][val], 3))) + ' '*(13-len(str(print_number_or_na(round(rating_of_cl[7][val], 3))))) + str(print_number_or_na(round(rating_of_cl[1][val], 3))) + ' '*(13 - len(str(print_number_or_na(round(rating_of_cl[1][val], 3)))))) 
        if rating_of_cl[6][val] != -99999:
             f.write('{:e}'.format(rating_of_cl[6][val]) +' '*(18-len('{:e}'.format(rating_of_cl[6][val]))))
        else:
             f.write('N/A' +' '*15)    
        
        if ref_protein in results[val].nothing:
            f.write('No amino acids in the reference protein\n')
        else:
            index_of_ref_protein = results[val].dirrss.index(ref_protein)
            f.write(str(cols[val][results[val].intact[index_of_ref_protein]][0]) + '-' + str(cols[val][results[val].intact[index_of_ref_protein]][-1]) + '\n')
    
    f.close()
    
    if len(results) > 1:
        clust_to_pdb.result_to_pse(aligned_pdb_folder, output_folder, ref_protein, rating_of_cl, results, cols)
        if create_pse:
            os.system('pymol -qc ' + os.path.join(output_folder, 'RESULTS.py'))

def rating(results, path_to_program):
    diams = np.array([i.diam for i in results])
    sils = np.array([i.sil for i in results])
    pdbflex_sils, pdbflex_diams = pdbflex_extract(path_to_program)

    min_sil = min(min(map(np.min, pdbflex_sils)), np.min(sils[sils != -99999]))
    max_sil = max(max(map(np.max, pdbflex_sils)), np.max(sils[sils != -99999]))
    min_diam = min(min(map(np.min, pdbflex_diams)), np.min(diams[sils != -99999]))
    max_diam = max(max(map(np.max, pdbflex_diams)), np.max(diams[sils != -99999]))

    scaler_sils_pdbflex = list(map(lambda k: (k - min_sil)/(max_sil - min_sil),  pdbflex_sils))
    scaler_diams_pdbflex = list(map(lambda k: (k - min_diam)/(max_diam - min_diam),  pdbflex_diams))
    
    diams_scaler = (diams - min_diam)/(max_diam - min_diam)
    sils_scaler = (sils - min_sil)/(max_sil - min_sil)

    statistic = [] 
    for i in range(len(scaler_sils_pdbflex)):
        statistic.append(np.median(scaler_sils_pdbflex[i]*scaler_diams_pdbflex[i]))
    
    mean_sil_diam = np.mean(np.array(statistic))
    std_sil_diam = np.std(np.array(statistic))

    scores = (sils_scaler*diams_scaler - mean_sil_diam)/std_sil_diam

    scores[sils == -99999] = -99999

    p_vals = scipy.stats.norm.sf(scores)
    specific_score = sils_scaler*diams_scaler

    specific_score[sils == -99999] = -99999
    p_vals[sils == -99999] = -99999
    diams_scaler[sils == -99999] = -99999
    sils_scaler[sils == -99999] = -99999

    return sorted(range(len(results)), key=lambda k: scores[k], reverse=True), scores, sils, diams, sils_scaler, diams_scaler, p_vals, specific_score

if __name__ == "__main__":
    print('''\n\n                       :-) Zebra3D (-:
      
      A tool for systematic analysis of 3D-structural diversity 
                and specificity in protein superfamilies
                
                  :-) v.''',format(v), d, '''(-:\n\n''')
    time_start = datetime.datetime.now()



    path_to_program =  os.path.dirname(os.path.abspath(sys.argv[0]))

    dict_of_sys_argv = dict([arg.split('=') for arg in sys.argv[1:]])
    if len(dict_of_sys_argv) == 0:
        print('''
Usage:   python3 Zebra3D.py aligned_pdbs=</path/to/folder> aligned_fasta=</path/to/file> output=</path/to/folder> [options]
Example: python3 Zebra3D.py aligned_pdbs=./input_pdbs aligned_fasta=./input.fasta output=./output

Mandatory input parameters:
===========================
aligned_pdbs=<string>  # Path to folder with aligned protein 3D-structures as separate files in the PDB format (each file should represent one chain)
aligned_fasta=<string> # Path to the corresponding sequence representation of the alignment in the FASTA format
output=<string>        # Path to folder to store results

Utilization of computing resources: 
===================================
cpu_threads=<int> # Number of parallel CPU threads to utilize (the default is "all" physically available)

Cluster analysis methods:
=========================
method=hdbscan              # Use HDBSCAN automatic method (default) 
method=optics               # Use OPTICS automatic method
method=dbscan eps=<float>   # Use DBSCAN method for manual fine-tuning of the results by specifying the ‘eps’ value (eps > 0)
min_size_of_subfamily=<int> # The purpose of this parameter is to regulate the minimal size of a subfamily/cluster within SSR.
                              The exact implementation of this parameter depends on the choice of the machine-learning cluster analysis method. 
                              See the on-line documentation for details at https://biokinet.belozersky.msu.ru/Zebra3D-parameters#min_size_of_subfamily

Selection of common core positions:
===================================
max_content_of_gaps=<int>      # Define the allowed gap content in alignment column, in % (at most 5%, by default)
max_content_of_mismatch=<int>  # Define the allowed 3D-mismatch content in alignment column, in % (at most 5%, by default)
mismatch_threshold=<float>     # Define the cut-off value to discriminate spatially aligned from misaligned residues, in angstroms (selected automatically)

Filtering/postprocessing parameters:
====================================
ref=<string>         # Set the reference protein by its name in the FASTA alignment (default is the first protein)
max_ssr_length=<int> # Maximum number of positions (residues) in a region. SSR of larger size will be dismissed (disabled by default, i.e. set to 9999)
max_outliers=<int>   # Maximum number of outliers. SSR with a larger % of outliers will be dismissed, in % (disabled by default, i.e. set to 100%)
exclude_ncterm=<int> # Dismiss SSRs that assign N-/C-terminal regions (first and last <int> residues of any PDB entry) to subfamilies

Special case options:
=====================
ssr_start=<int> ssr_end=<int> # Evaluate one particular region as a potential SSR by specifying the IDs of first and last residues as in the reference protein 

PyMol parameters:
=================
compile_pymol_pse=[true|false] # If set to false, only python scripts for PyMol sessions with 3D-annotation of results will be generated, and 
                               # compilation of the corresponding PyMol binary files will be disabled, to facilitate the analysis of 
                               # very large input datasets (default=true)

Documentation:
==============
The latest version of the program, documentation and examples are available open-access at https://biokinet.belozersky.msu.ru/Zebra3D
              ''')    
        quit()

    if 'aligned_fasta' in dict_of_sys_argv and 'aligned_pdbs' in dict_of_sys_argv:
        aligned_pdb_folder = os.path.abspath(dict_of_sys_argv['aligned_pdbs'])
        aligned_fasta = os.path.abspath(dict_of_sys_argv['aligned_fasta'])
    else: 
        raise Exception('Error: Not enough input arguments to run the program')

    if 'compile_pymol_pse' in dict_of_sys_argv:
        create_pse = dict_of_sys_argv['compile_pymol_pse'] == 'true'
    else:
        create_pse = True

    if 'cpu_threads' in dict_of_sys_argv:
        cpu_threads = int(dict_of_sys_argv['cpu_threads'])
    else:
        cpu_threads = multiprocessing.cpu_count()

    if 'method' in dict_of_sys_argv:
        if dict_of_sys_argv['method'] not in ['optics', 'dbscan', 'hdbscan']: raise Exception('Method must be optics, dbscan or hdbscan')
        method_of_clustering = dict_of_sys_argv['method']
    else:
         method_of_clustering = 'hdbscan'
    
    if 'eps' in dict_of_sys_argv:
        eps_for_clustering = float(dict_of_sys_argv['eps'])
    else:
        if method_of_clustering == 'dbscan':
            raise Exception('If you use dbscan-method, you should choose eps')
        eps_for_clustering = 3

    if 'max_content_of_gaps' in dict_of_sys_argv:
        perс_of_gaps = float(dict_of_sys_argv['max_content_of_gaps'])/100.

    if 'max_content_of_mismatch' in dict_of_sys_argv:
        max_content_of_mismatch = float(dict_of_sys_argv['max_content_of_mismatch'])/100.
    else:
        max_content_of_mismatch = 0.05

    if 'max_outliers' in dict_of_sys_argv:
        max_outliers = float((dict_of_sys_argv['max_outliers']))/100.
    else:
        max_outliers = 1.0
        #max_outliers = 0.4

    if 'exclude_ncterm' in dict_of_sys_argv:
        exclude_ncterm = int(dict_of_sys_argv['exclude_ncterm'])
    else:
        exclude_ncterm = -1

    if 'output' in dict_of_sys_argv:
        output_folder = os.path.abspath(dict_of_sys_argv['output'])
    else:
        raise Exception('Choose folder for output')

    if os.path.exists(output_folder) and os.path.isdir(output_folder):
        if os.listdir(output_folder):
            raise Exception('Error: Folder '+output_folder+' exists and is not empty')
    else:
        os.makedirs(output_folder)

    if not os.path.exists(aligned_fasta): raise Exception('Error: No fasta file ' + aligned_fasta+' in here')
    if not os.path.exists(aligned_pdb_folder) or not os.path.isdir(aligned_pdb_folder): raise Exception('Error: No folder '+aligned_pdb_folder+ ' in here')

    aligned_pdb_folder_check(aligned_pdb_folder)
    
    print('Info: Started at', str(time_start).split('.')[0])
    
    tmp = par_to_al.par_to_al(aligned_fasta, aligned_pdb_folder)
    dirs = tmp[0]
    align = tmp[1]
    align_fasta = tmp[2]
    dict_fasta_to_dir = tmp[3]
    dict_dir_to_fasta = tmp[4]
    heaps = []
    
    if len(align) < 2:
        raise Exception('Error: Number of proteins is less than two or something wrong with data reading')
    if len(align[0]) < 2:
        raise Exception('Error: Something wrong with data reading')
  
    if 'ref' in dict_of_sys_argv:
        if dict_of_sys_argv['ref'] in dict_fasta_to_dir:
            ref_protein = dict_fasta_to_dir[dict_of_sys_argv['ref']]
        else:
            raise Exception("Error: Your ref-protein does not exist in aligned-pdbs folder or fasta-file")

        if ref_protein not in dirs: 
            raise Exception("Error: Your ref-protein does not exist in aligned-pdbs folder or fasta-file")
    else:
        ref_protein = dirs[0]
    
    if 'max_ssr_length' in dict_of_sys_argv:
        max_ssr_length = int(dict_of_sys_argv['max_ssr_length'])
    else:
        max_ssr_length = 9999
        #max_ssr_length = math.ceil(len([x for x in align[dirs.index(ref_protein)] if x != '-'])*0.1)
            
    if 'min_size_of_subfamily' in dict_of_sys_argv:
        min_size_of_subfamily = int(dict_of_sys_argv['min_size_of_subfamily'])
    else:
        min_size_of_subfamily = int(max(math.floor(len(dirs)*0.1), 2))
  
    printing_input_info(dict_of_sys_argv, dict_dir_to_fasta[ref_protein], method_of_clustering, eps_for_clustering, perс_of_gaps, min_size_of_subfamily, max_outliers, create_pse, max_ssr_length, max_content_of_mismatch, exclude_ncterm, cpu_threads)

    par_to_al.check_if_folder_aligned_and_backbone_is_ok(dirs, align, aligned_pdb_folder)

    align_base = copy.deepcopy(align)

    print('Info: Total proteins in the 3D-alignment is {}'.format(len(dirs)))

    if 'ssr_start' in dict_of_sys_argv and 'ssr_end' not in dict_of_sys_argv or 'ssr_start' not in dict_of_sys_argv and 'ssr_end' in dict_of_sys_argv:
        raise Exception('You should use ssr_start and ssr_end together')


    c_term = False
    n_term = False
    
    if 'ssr_start' in dict_of_sys_argv and 'ssr_end' in dict_of_sys_argv:
        ssr_start = int(dict_of_sys_argv['ssr_start'])
        ssr_end = int(dict_of_sys_argv['ssr_end'])
        heaps_ready = get_heaps_if_ssr_start_and_ssr_end(ref_protein, dirs, align, ssr_start, ssr_end)

    else:
        heaps_ready = []

        if 'mismatch_threshold' not in dict_of_sys_argv:
            for i in range(len(align[0])):
                if len(num_of_let(align, i)) >= len(align)*(1-perс_of_gaps):
                    heaps.append(i)
    
            if len(heaps) == 0:
                raise Exception("Error: It seems that the number of common core residues is not sufficient for cluster analysis. You should increase the 'max_content_of_gaps' parameter or reconsider your input alignment")
        

            print('Info: Total alignment positions that passed gap threshold is {}'.format(len(heaps)))
        
            rmsds_to_show = []
            pool = Pool(cpu_threads)
            all_args = [(heaps[i], dirs, align, aligned_pdb_folder) for i in range(len(heaps))]
            results = pool.map(wrapped_align_for_cut, all_args)
            for i in results:
                rmsds_to_show.append(i)
            try:
                y_axis = sorted(rmsds_to_show)
                Perc_5 = math.floor(len(y_axis)*0.05)
                x_axis = [i for i in range(len(rmsds_to_show))]
                data = np.asarray(list(zip(x_axis[Perc_5:len(x_axis)-Perc_5],y_axis[Perc_5:len(x_axis)-Perc_5])))
                elbow_index = find_elbow(data, get_data_radiant(data))
                cut = data[elbow_index][1]
            except Exception:
                print('Warning: Some problems with parameter definition for mismatch_threshold. The parameter will be set to 5')
                cut = 5
            if cut == 0 or cut == y_axis[Perc_5]:
                cut = y_axis[-1]
        else:
            cut = float(dict_of_sys_argv['mismatch_threshold'])

        print('Info: The automatically selected cut-off value to discriminate spatially aligned from misaligned residues is {} A'.format(round(cut,3)))
        heaps = []

        for i in range(len(align[0])):
            if len(num_of_let(align, i)) > len(align) * (1-max_content_of_mismatch):
                heaps.append(i)

        print('Info: Selecting the common core positions and variable regions to be further evaluated as potential SSRs')
        pool = Pool(cpu_threads)
        all_args = [(heaps[i], dirs, align, aligned_pdb_folder , cut) for i in range(len(heaps))]
        results = pool.map(wrapped_align_improvement, all_args)
        for i, heap in enumerate(heaps):
            for j in results[i]:
                align[j][heap] = '-'

        heaps = []

        for i in range(len(align[0])):
            if len(num_of_let(align, i)) > len(align)*(1-max_content_of_mismatch):
                heaps.append(i)

        if len(heaps) < 2:
           raise Exception("Error: It seems that the number of common core residues is not sufficient for cluster analysis. You should increase the 'max_content_of_mismatch' parameter or reconsider your input alignment")
    
        if len(heaps) < 5:
            print("Warning: It seems that the number of common core residues is not sufficient for cluster analysis. You may increase the 'max_content_of_mismatch' parameter or reconsider your input alignment to improve the results")
        
        print('Info: Total common core positions is {}'.format(len(heaps)))


        for i in range(len(heaps)-1):
            if (heaps[i+1]-heaps[i]) != 1:
                heaps_ready.append([heaps[i], heaps[i+1]])
        if heaps[-1] != len(align[0])-1:
            heaps_ready.append([heaps[-1],len(align[0])])
            c_term = True
        if heaps[0] != 0:
            heaps_ready.insert(0,[-1,heaps[0]])
            n_term = True

    print('Info: Total regions to be evaluated as potential SSRs is {}'.format(len(heaps_ready)))
    results = []
    cols = []
    ssr_with_long_subf = []
    ssr_with_many_outliers = []
    ssr_with_no_diversity = []

    bar = IncrementalBar('Info: Cluster analysis in progress', max = len(heaps_ready))

    for flag in range(len(heaps_ready)):

        bar.next()
        
        align_of_site = []

        for i in range(len(dirs)):
            align_of_site.append('>' + dirs[i][:-4])
            align_of_site.append(align_fasta[i][heaps_ready[flag][0]+1:heaps_ready[flag][1]])

        set_of_lens = set()
        col = []
        for j in range(len(dirs)):
            tmp = get_res_in_int([heaps_ready[flag][0]+1,heaps_ready[flag][1]-1], j, align_base)
            col.append(tmp)

        tmp = 0
        for i in col:
            if len(i) > 1: 
                tmp = 1
        if tmp == 0: 
            continue
        res = groups_by_optics(aligned_pdb_folder, align_base, dirs, col, align_of_site, method_of_clustering, eps_for_clustering, min_size_of_subfamily, cpu_threads)

        if len(res.lab) == 0:
            continue

        if (res.perc_of_out < max_outliers and res.max_ssr_length < max_ssr_length and len(set(res.lab)) > 1 and n_c_not_exclude(res, flag, exclude_ncterm, n_term, c_term, len(heaps_ready))) or ('ssr_start' in dict_of_sys_argv and 'ssr_end' in dict_of_sys_argv):
            results.append(res)
            cols.append(col)

        elif len(set(res.lab)) < 2:
            ssr_with_no_diversity.append((res, col))

        elif res.max_ssr_length > max_ssr_length:
            ssr_with_long_subf.append((res, col))

        elif res.perc_of_out > max_outliers:
            ssr_with_many_outliers.append((res, col))

    bar.finish()

    printing_warnings_skipped_ssr_long_subf(ssr_with_long_subf, ref_protein)
    printing_warnings_skipped_ssr_many_outliers(ssr_with_many_outliers, ref_protein)
    printing_warnings_skipped_no_diversity(ssr_with_no_diversity, ref_protein)

    if len(results) == 0:
        raise Exception('No SSR in results. Increase max_outliers or max_ssr_length or change method of clustering')

    rating_of_cl = rating(results, path_to_program)

    printing_results(dirs, aligned_pdb_folder, aligned_fasta, results, rating_of_cl, cols, output_folder, time_start, ref_protein, dict_dir_to_fasta[ref_protein], dict_of_sys_argv, method_of_clustering, eps_for_clustering, perс_of_gaps, min_size_of_subfamily, max_outliers, create_pse, max_ssr_length, max_content_of_mismatch, exclude_ncterm)
    printing(aligned_pdb_folder, results, rating_of_cl, cols, create_pse, output_folder, ref_protein)
    
    print('Info: Zebra3D analysis completed. Bye!')
    time_stop = datetime.datetime.now()
    print('Info: Ended at', str(time_stop).split('.')[0])
    print('''\n----------------------------------------------------------------------------------
Zebra3D Copyright (C) 2020-2021 Timonina D., Sharapova Y., Švedas V., Suplatov D.
This software is licensed under GNU GPL as published by the FSF, either version 3 
of the License, or any later version (see LICENSE.txt for details)

If you find Zebra3D or its results useful please cite our work:
Timonina D., Sharapova Y., Švedas V., Suplatov D. (2021) Bioinformatic analysis 
of subfamily-specific regions in 3D-structures of homologs to study functional 
diversity and conformational plasticity in protein superfamilies. submitted
----------------------------------------------------------------------------------\n''')
