#    Zebra3D: Tool for bioinformatic analysis of 3D-determinants of functional diversity in protein superfamilies
#    Copyright (C) 2020-2021 Timonina D., Sharapova Y., Švedas V., Suplatov D.
#    "Dmitry Suplatov" <d.a.suplatov@belozersky.msu.ru>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import module
import reading
import ali_count
from Bio import pairwise2
import numpy as np
import rmsdm
import math
import os

def check_if_folder_aligned_and_backbone_is_ok(dirs, align, aligned_clique):
    list_of_bad_backbone_aa = {}

    prots = []
    
    for i in dirs:
        prot = reading.readprot(os.path.join(aligned_clique,i))
        prots.append(prot[1])

    for protein in range(len(align)):
        for pos in range(len(align[0])):
            if align[protein][pos] != '-':
                if 'CA' in prots[protein][align[protein][pos]] and 'C' in prots[protein][align[protein][pos]] and 'N' in prots[protein][align[protein][pos]] and 'O' in prots[protein][align[protein][pos]]:
                    continue
                else:
                    if protein in list_of_bad_backbone_aa:
                        list_of_bad_backbone_aa[protein].append(align[protein][pos])
                    else:
                        list_of_bad_backbone_aa[protein] = [align[protein][pos]]

                    align[protein][pos] = '-'

    for i in list_of_bad_backbone_aa:
        print('Warning: PDB entry {} contains incomplete set of backbone atoms for amino acid(s)'.format(dirs[i]), list_of_bad_backbone_aa[i])


    for i in range(len(align)):
        for j in range(i, len(align)):
            rmsds = []
            for pos in range(len(align[0])):
                
                if align[i][pos] == '-' or align[j][pos] == '-':
                    continue
                
                P1 = []
                P2 = []
                P1.append(prots[i][align[i][pos]]['CA'])
                P2.append(prots[j][align[j][pos]]['CA'])
                rmsds.append(rmsdm.rmsd(P1, P2))

            if len(rmsds) != 0 :
                mean_rmsd = sum(rmsds)/len(rmsds)
                if mean_rmsd > 9:
                    print('Warning: Average RMSD between {} and {} is {} what may indicate poor alignment quality of the two proteins'.format(dirs[i],dirs[j],str(mean_rmsd)))

    return
    
def align_for_cut(heap, dirs, align, aligned_clique):

    prots = []
    for i in dirs:
        prot = reading.readprot(os.path.join(aligned_clique,i))
        prots.append(prot[1])
    RMSD_MATR = np.zeros((len(align),len(align))) 
    for i in range(len(align)):
        for j in range(i, len(align)): 
            if align[i][heap] == '-' or align[j][heap] == '-': 
                RMSD_MATR[i][j] = 0
                RMSD_MATR[j][i] = 0
            else:
                P1 = []
                P2 = []
                P1.append(prots[i][align[i][heap]]['N'])
                P1.append(prots[i][align[i][heap]]['CA'])
                P1.append(prots[i][align[i][heap]]['C'])
                P1.append(prots[i][align[i][heap]]['O'])

                P2.append(prots[j][align[j][heap]]['N'])
                P2.append(prots[j][align[j][heap]]['CA'])
                P2.append(prots[j][align[j][heap]]['C'])
                P2.append(prots[j][align[j][heap]]['O'])
                RMSD_MATR[i][j] = rmsdm.rmsd(P1, P2)
                RMSD_MATR[j][i] = RMSD_MATR[i][j]

    maxx = np.max(RMSD_MATR)
    return maxx

def convertion(a):    
    aminoac = {
    "G" : 'GLY',
    "L" : 'LEU',
    "Y" : 'TYR',
    "S" : 'SER',
    "E" : 'GLU',
    "Q" : 'GLN',
    "D" : 'ASP',
    "N" : 'ASN',
    "F" : 'PHE',
    "A" : 'ALA',
    "K" : 'LYS',
    "R" : 'ARG',
    "H" : 'HIS',
    "C" : 'CYS',
    "V" : 'VAL',
    "P" : 'PRO',
    "W" : 'TRP',
    "I" : 'ILE',
    "M" : 'MET',
    "T" : 'THR',
    "GLY" : 'G',
    "LEU" : 'L',
    "TYR" : 'Y',
    "SER" : 'S',
    "GLU" : 'E',
    "GLN" : 'Q',
    "ASP" : 'D',
    "ASN" : 'N',
    "PHE" : 'F',
    "ALA" : 'A',
    "LYS" : 'K',
    "ARG" : 'R',
    "HIS" : 'H',
    "CYS" : 'C',
    "VAL" : 'V',
    "PRO" : 'P',
    "HYP" : 'hP',
    "TRP" : 'W',
    "ILE" : 'I',
    "MET" : 'M',
    "THR" : 'T',
    }
    try:
        b = aminoac[a]
    except Exception:
        b = 'X'
    return b
        
def par_to_al(fassta, aligned_pdb_folder): 
    """ 
    returns the list - an alignment 
    with numbers of amino acids, arguments are alignment file 
    and folder with proteins
    """
    align_fasta = []	
    alignment = []
    dirs = []
    fasta = open(fassta, 'r')
    names_of_prot = module.names_of_prot(fasta)
    seq_from_fasta = module.seq_from_fasta(fasta)
    dirs_in_pdb_folder = os.listdir(aligned_pdb_folder)
    dict_fasta_to_dir = {}
    dict_dir_to_fasta = {}

    if len(names_of_prot) != len(os.listdir(aligned_pdb_folder)):
        raise Exception('Error: number of proteins in fasta-file is not equal to number of proteins in pdb-files folder')
    for i in range(len(names_of_prot)):
        if names_of_prot[i]+'.pdb' in dirs_in_pdb_folder:
            dir = names_of_prot[i] + '.pdb'
            dict_fasta_to_dir[names_of_prot[i]] =  names_of_prot[i] + '.pdb'
            dict_dir_to_fasta[names_of_prot[i] + '.pdb'] = names_of_prot[i]
        elif names_of_prot[i].replace(':','_')+'.pdb' in dirs_in_pdb_folder:
            dir = names_of_prot[i].replace(':', '_') + '.pdb'
            dict_fasta_to_dir[names_of_prot[i]] = names_of_prot[i].replace(':', '_') + '.pdb'
            dict_dir_to_fasta[names_of_prot[i].replace(':', '_') + '.pdb'] = names_of_prot[i]
        elif names_of_prot[i].split(':')[0]+'.pdb' in dirs_in_pdb_folder:
            dir = names_of_prot[i].split(':')[0]+'.pdb'
            dict_fasta_to_dir[names_of_prot[i]] = names_of_prot[i].split(':')[0]+'.pdb'
            dict_dir_to_fasta[names_of_prot[i].split(':')[0]+'.pdb'] = names_of_prot[i]
        else:
            raise Exception('Warning: Lack of file ' + names_of_prot[i] + '.pdb in input folder')
        alignment.append([])
        dirs.append(dir)
        align_fasta.append(seq_from_fasta[i])
        prot = reading.readprot(os.path.join(aligned_pdb_folder,dir))
        seq_from_pdb =''
        for j in prot[2]:
            seq_from_pdb += convertion(prot[0][j])
        alignment_tmp = pairwise2.align.globalxx(seq_from_fasta[i].replace("-", ""), seq_from_pdb)
        c = [i for i in range(len(seq_from_fasta[i].replace("-", "")))]
        c_res = ali_count.fasta_bind_site(c, alignment_tmp[0][0], alignment_tmp[0][1])
        k = 0
        for j in seq_from_fasta[i]:
            if j == '-':
                alignment[-1].append('-')
                continue
            elif j != '-':
                if c_res[k] != -1:
                    alignment[-1].append(prot[2][c_res[k]])
                elif c_res[k] == -1:
                    alignment[-1].append('-')
                k += 1
    return dirs, alignment, align_fasta, dict_fasta_to_dir, dict_dir_to_fasta

def align_improvement_rec(heap, dirs, align, aligned_clique, cut, RMSD_MATR, result):
    
    i_max = np.unravel_index(RMSD_MATR.argmax(), RMSD_MATR.shape)[0]
    j_max = np.unravel_index(RMSD_MATR.argmax(), RMSD_MATR.shape)[1]
    maxx = np.max(RMSD_MATR)
    
    RMSD_MATR[i_max][j_max] = 0
    RMSD_MATR[j_max][i_max] = 0
    if maxx < cut: return
    else: 
        max1 = RMSD_MATR[i_max].sum()
        max2 = RMSD_MATR[j_max].sum()
        if max1 > max2:
            align[i_max][heap] = '-'
            result.append(i_max)
            for i in range(len(align)): 
                RMSD_MATR[i_max][i] = 0
                RMSD_MATR[i][i_max] = 0
        else: 
            align[j_max][heap] = '-' 
            result.append(j_max)
            for i in range(len(align)): 
                RMSD_MATR[j_max][i] = 0
                RMSD_MATR[i][j_max] = 0
        align_improvement_rec(heap, dirs, align, aligned_clique, cut, RMSD_MATR, result)
        return

def align_improvement(heap, dirs, align, aligned_clique, cut):
    result = []
    prots = []
    for i in dirs:
        prot = reading.readprot(os.path.join(aligned_clique,i))
        prots.append(prot[1])
    RMSD_MATR = np.zeros((len(align),len(align))) 
    for i in range(len(align)):
        for j in range(i, len(align)): 
            if align[i][heap] == '-' or align[j][heap] == '-': 
                RMSD_MATR[i][j] = 0
                RMSD_MATR[j][i] = 0
            else:
                P1 = []
                P2 = []
                P1.append(prots[i][align[i][heap]]['N'])
                P1.append(prots[i][align[i][heap]]['CA'])
                P1.append(prots[i][align[i][heap]]['C'])
                P1.append(prots[i][align[i][heap]]['O'])
                P2.append(prots[j][align[j][heap]]['N'])
                P2.append(prots[j][align[j][heap]]['CA'])
                P2.append(prots[j][align[j][heap]]['C'])
                P2.append(prots[j][align[j][heap]]['O'])
                RMSD_MATR[i][j] = rmsdm.rmsd(P1, P2)
                RMSD_MATR[j][i] = RMSD_MATR[i][j]

    i_max = np.unravel_index(RMSD_MATR.argmax(), RMSD_MATR.shape)[0]
    j_max = np.unravel_index(RMSD_MATR.argmax(), RMSD_MATR.shape)[1]
    maxx = np.max(RMSD_MATR)

    RMSD_MATR[i_max][j_max] = 0
    RMSD_MATR[j_max][i_max] = 0
    if maxx < cut: return result
    else: 
        max1 = RMSD_MATR[i_max].sum()
        max2 = RMSD_MATR[j_max].sum()
        if max1 > max2:
            align[i_max][heap] = '-'
            result.append(i_max)
            for i in range(len(align)): 
                RMSD_MATR[i_max][i] = 0
                RMSD_MATR[i][i_max] = 0
        else: 
            align[j_max][heap] = '-'  
            result.append(j_max)
            for i in range(len(align)): 
                RMSD_MATR[j_max][i] = 0
                RMSD_MATR[i][j_max] = 0
        align_improvement_rec(heap, dirs, align, aligned_clique, cut, RMSD_MATR, result)
        return result
