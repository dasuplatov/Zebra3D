#!/bin/bash

echo 
echo "This script will execute this example on Linux OS"
echo 

echo -n "Probing Python3 ... "
python3=`which python3 2>/dev/null`
if [ ! -f "$python3" ] || [ ! -x "$python3" ]; then
    echo "error"
    echo "Error: Python3 not installed or not executable or not in the PATH system variable"
    exit 
fi
echo "OK"

echo -n "Probing Zebra3D ... "
zebra3d="../Zebra3D.py"
if [ ! -f "$zebra3d" ]; then
    echo "error"
    echo "Error: Zebra3D.py was not found in the parent folder"
    exit 
fi
echo "OK"

echo "Running Zebra3D ..."

sleep 1

$python3 $zebra3d aligned_pdbs=./aligned_pdbs/ aligned_fasta=strcore_A-z1w7c3azfsyp7g.fasta output=results exclude_ncterm=5

echo ""
echo "What's next?"
echo ""
echo "View the results summary:"
echo "cat results/RESULTS.txt"
echo ""
echo "View the 3D-annotation of the SSR #1 (the "best" region, according to the Zebra3D's scoring assessment)"
echo "pymol results/ssr_001.pse"
echo ""
echo "See explanation of the results at https://biokinet.belozersky.msu.ru/zebra3d-output"
echo ""






