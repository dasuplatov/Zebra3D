#    Zebra3D: Tool for bioinformatic analysis of 3D-determinants of functional diversity in protein superfamilies
#    Copyright (C) 2020-2021 Timonina D., Sharapova Y., Švedas V., Suplatov D.
#    "Dmitry Suplatov" <d.a.suplatov@belozersky.msu.ru>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

def fasta_bind_site(c,seq1, seq2):
    a = []
    for num in range(len(c)):
        m = -1
        k1 = 0
        while m != c[num]:
            if seq1[k1] != '-':
                m += 1
            k1 += 1
        k1 = k1 - 1
        m = 0
        k2 = -1
        if seq2[k1] != '-':
            while m != k1+1:
                if seq2[m] != '-': k2 += 1
                m += 1
        elif seq2[k1] == '-': k2 = -1

        a.append(k2)
    return(a)
