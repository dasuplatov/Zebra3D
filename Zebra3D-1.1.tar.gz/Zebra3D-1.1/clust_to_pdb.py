#    Zebra3D: Tool for bioinformatic analysis of 3D-determinants of functional diversity in protein superfamilies
#    Copyright (C) 2020-2021 Timonina D., Sharapova Y., Švedas V., Suplatov D.
#    "Dmitry Suplatov" <d.a.suplatov@belozersky.msu.ru>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import os
import sys
import numpy as np

def resid(col, intact, i):
    if len(col[intact[i]]) < 15: 
        return '+'.join([str(j) for j in col[intact[i]]])
    else:
        return str(col[intact[i]][0]) + '-' + str(col[intact[i]][-1])

def result_to_pse(aligned_pdb_folder, output_folder, ref_protein, rating_of_cl, results, cols):
    f = open(os.path.join(output_folder, 'RESULTS.py'), 'w')
    f.write('#BEGIN\n')
    f.write('cmd.bg_color("white")\n')
    f.write('cmd.load(r"'+os.path.join(aligned_pdb_folder, ref_protein) + '", "' + ref_protein + '")\n')
    f.write('cmd.color("gray", "' + ref_protein + '")\n')
    f.write('cmd.color("cyan", "elem C")\n')

    s0_x = 255
    s1_x = 200
    s0_y = 0
    s1_y = 200
    s0_z = 0
    s1_z = 200
    z_min = np.min(rating_of_cl[1])
    z_max = np.max(rating_of_cl[1])

    for i, val in enumerate(rating_of_cl[0]):
        z_cur = rating_of_cl[1][val]
        coeff = 3. * (z_cur - z_min) / 4. / (z_max - z_min) + 0.25
        color_r = s1_x + coeff * (s0_x - s1_x)
        color_g = s1_y + coeff * (s0_y - s1_y)
        color_b = s1_z + coeff * (s0_z - s1_z)

        if ref_protein in results[val].nothing:
            pass
        else:
            index_of_ref_protein = results[val].dirrss.index(ref_protein)
            f.write('cmd.select("SSR_' + str(i+1) + '", "' + ref_protein + ' and resi ' + resid(cols[val], results[val].intact, index_of_ref_protein) + '")\n')
            f.write('cmd.set_color("temp_colorSSR_{}", "[{},{},{}]")\n'.format(i+1, color_r, color_g, color_b))
            f.write('cmd.color("temp_colorSSR_{}", "SSR_{} and name CA")\n'.format(i+1, i+1))

    f.write('cmd.show("cartoon")\n')
    f.write('cmd.hide("lines")\n')
    f.write('cmd.hide("nonbonded")\n')
    f.write('cmd.hide("lines")\n')
    f.write('cmd.set("stick_radius", "0.3")\n')

    f.write('cmd.color("chartreuse", "hetatm and element C")\n')
    f.write('cmd.show("sticks", "hetatm")\n')
    f.write('cmd.color("orange", "hetatm and not element C+H+N+O+S+P")\n')
    f.write('cmd.show("spheres", "polymer and hetatm and not element C+H+N+O+S+P")\n')
    f.write('cmd.set("sphere_scale", "0.5", "hetatm")\n')
    f.write('cmd.set("cartoon_gap_cutoff", "0")\n')
    f.write('cmd.save(r"' + os.path.join(output_folder, 'RESULTS.pse")'))
    f.close()

def clust_to_pse(aligned_pdb_folder, flag, d, l, col, intact, nothing, output_folder, ref_protein):
    f = open(os.path.join(output_folder, 'ssr_'+'{0:03}'.format(flag)+'.py'), 'w')
    f.write('#BEGIN\n')
    f.write('cmd.bg_color("white")\n')
    sorted_results = sorted(range(len(intact)), key=lambda k: l[k] if l[k] > -1 else sys.maxsize)
    for i in sorted_results:
        if d[i] == ref_protein:
            mark = 'Ref_'
        else:
            mark = ''

        if l[i] > -1:
            f.write('cmd.load(r"'+os.path.join(aligned_pdb_folder,str(d[i]))+'", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+'")\n')
            f.write('cmd.color("silver", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+'")\n')
        else:
            f.write('cmd.load(r"'+os.path.join(aligned_pdb_folder,str(d[i]))+'", "'+mark+'Outlier_'+d[i]+'")\n')
            f.write('cmd.color("silver", "'+mark+'Outlier_'+d[i]+'")\n')
        
        if l[i] == 0:
            f.write('cmd.color("lightpink", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == 1:
            f.write('cmd.color("palegreen", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == 2:
            f.write('cmd.color("lightblue", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == 3:
            f.write('cmd.color("paleyellow", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == 4:
            f.write('cmd.color("wheat", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == 5:
            f.write('cmd.color("palecyan", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == 6:
            f.write('cmd.color("lightorange", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == 7:
            f.write('cmd.color("bluewhite", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        elif l[i] == -1:
            f.write('cmd.color("'+str(l[i]+3)+'", "'+mark+'Outlier_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
        else:
            f.write('cmd.color("'+str(l[i]+3)+'", "'+mark+'SubFam'+str(l[i]+1)+'_'+d[i]+' and resi '+resid(col, intact, i)+'")\n')
    
    for i in nothing:
        if i == ref_protein:
            mark = 'Ref_'
        else:
            mark = ''
        f.write('cmd.load(r"'+os.path.join(aligned_pdb_folder,str(i))+'", "'+mark+'Null_data_'+str(i)+'")\n')
        f.write('cmd.color("silver", "'+mark+'Null_Data_'+i+'")\n')
    f.write('cmd.show("cartoon")\n')
    f.write('cmd.hide("lines")\n')
    f.write('cmd.hide("nonbonded")\n')
    f.write('cmd.hide("lines")\n')
    f.write('cmd.set("stick_radius", "0.3")\n')

    f.write('cmd.color("chartreuse", "hetatm and element C")\n')
    f.write('cmd.show("sticks", "hetatm")\n')
    f.write('cmd.color("orange", "hetatm and not element C+H+N+O+S+P")\n')
    f.write('cmd.show("spheres", "polymer and hetatm and not element C+H+N+O+S+P")\n')
    f.write('cmd.set("sphere_scale", "0.5", "hetatm")\n')
    f.write('cmd.set("cartoon_gap_cutoff", "0")\n')

    f.write('cmd.save(r"'+os.path.join(output_folder, 'ssr_'+'{0:03}'.format(flag)+'.pse")'))
    f.close()
    return
