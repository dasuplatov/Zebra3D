#    Zebra3D: Tool for bioinformatic analysis of 3D-determinants of functional diversity in protein superfamilies
#    Copyright (C) 2020-2021 Timonina D., Sharapova Y., Švedas V., Suplatov D.
#    "Dmitry Suplatov" <d.a.suplatov@belozersky.msu.ru>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import numpy as np
from reading import *
import os
import shutil
from rmsdm import rmsd
from sklearn.cluster import *
from sklearn.metrics import silhouette_score
import scipy
import random  
from functools import partial
from multiprocessing import Process, Pool
import hdbscan

def rmsd_script(ar1, ar2):
    rmsds = []
    len1 = len(ar1)
    len2 = len(ar2)
    if len1 == len2: return rmsd(ar1, ar2)
    if len2 < len1:        
        len1, len2 = len2, len1
        ar1, ar2 = ar2, ar1
    for i in range(1000):
        list_of_aa = sorted(list(random.sample([j for j in range(len2)],len1)))
        ar3 = [ar2[j] for j in list_of_aa]    
        rmsds.append(rmsd(ar1,ar3))  
    return np.mean(np.asarray(rmsds))    
    
class Cluster:
    def __init__(self, dirrss, lab, num_of_cores_intact, sil, nothing, diam, ratio, perc_of_out, align_of_site, max_ssr_length, num_aa_in_longest_prot, num_of_outliers, num_of_subf):
        self.lab = lab
        self.dirrss = dirrss
        self.intact = num_of_cores_intact
        self.sil = sil
        self.nothing = nothing
        self.diam = diam
        self.ratio = ratio
        self.perc_of_out = perc_of_out 
        self.align_of_site = align_of_site
        self.max_ssr_length = max_ssr_length
        self.num_aa_in_longest_prot = num_aa_in_longest_prot
        self.num_of_outliers = num_of_outliers
        self.num_of_subf = num_of_subf

def B_maker(P_array, i):
    arr = []
    for j in range(0,i):
        arr.append(0)
    for j in range(i,len(P_array)):
        arr.append(rmsd_script(P_array[i], P_array[j]))
    return arr

def get_res_in_int(interval, i, align):
    """
    Interval including borders
    """
    res = []
    for j in range(interval[0], interval[1]+1):
        if align[i][j] != '-': res.append(int(align[i][j]))    
    return res

def frange(start, stop, step):
    i = start
    while i < stop:
         yield i
         i += step

def num_of_let(align, i): 
    sett = set()
    for j in range(len(align)):
        if align[j][i] != '-': sett.add(j)
    return sett
       
def groups_by_optics(aligned_pdb_folder, align, dirs, interval, align_of_site, method_of_clustering, eps_for_clustering, min_size_of_subfamily, cpu_threads):
    nothing = []
    num_of_cores_intact = []
    dirrss = []
    P_array = []
    
    amount_of_aa_in_prot = []
    
    for i in range(len(dirs)):
        prot = readprot(os.path.join(aligned_pdb_folder,dirs[i]))
 
        num_of_aa = []
        for j in interval[i]:
            num_of_aa.append(j)

        P = []
        for j in num_of_aa:
            if 'N' in prot[1][j]:
                P.append(prot[1][j]['N'])
            if 'CA' in prot[1][j]:
                P.append(prot[1][j]['CA'])
            if 'C' in prot[1][j]:
                P.append(prot[1][j]['C'])
            if 'O' in prot[1][j]:
                P.append(prot[1][j]['O'])        
        if len(P) == 0:
            nothing.append(dirs[i])
            continue   
        
        amount_of_aa_in_prot.append(len(num_of_aa))
        num_of_cores_intact.append(i)
        P_array.append(P) 
        dirrss.append(dirs[i]) 
    
    B = []
    p = Pool(cpu_threads)
    arg = range(len(P_array))
    func = partial(B_maker, P_array)
    res = p.map(func, arg)
    
    for j in res:
        B.append(j)
    B = np.asarray(B)
    for i in range(len(P_array)):
        for j in range(i,len(P_array)):
            B[j][i] = B[i][j]

    if len(dirrss) == 1:
        result = Cluster(dirrss, [-1], num_of_cores_intact, 0, nothing, 0, 0, 1, align_of_site, amount_of_aa_in_prot[0], amount_of_aa_in_prot[0], 1, 0)
        return result
    if len(dirrss) == 0:
        result = Cluster(dirrss, [], num_of_cores_intact, 0, nothing, 0, 0 ,0, align_of_site, 0, 0, 0, 0)
        return result 
    
    if method_of_clustering == 'hdbscan':
               clusterer = hdbscan.HDBSCAN(min_cluster_size=min(min_size_of_subfamily,len(dirrss)))    
    elif method_of_clustering == 'optics':
        clusterer = OPTICS(metric='precomputed', min_samples=min(min_size_of_subfamily,len(dirrss)), n_jobs=cpu_threads)
    elif method_of_clustering == 'dbscan':
        clusterer = DBSCAN(metric='precomputed', min_samples=min(min_size_of_subfamily,len(dirrss)), eps=eps_for_clustering, n_jobs=cpu_threads)
    
    db = clusterer.fit(B)

    lab = db.labels_
    
    set_lab_outl = []
    lab_fixed = []
    for i, val in enumerate(lab):
        if val == -1: set_lab_outl.append(i)
        if val != -1: lab_fixed.append(lab[i])
    B_fixed = np.delete(B, set_lab_outl, axis = 0)
    B_fixed = np.delete(B_fixed, set_lab_outl, axis = 1)

    if (len(set(lab)) > 2 and list(lab).count(-1) > 0) or (len(set(lab)) > 1 and list(lab).count(-1) == 0):
        mean_diams_clusters = []
        sil = silhouette_score(B_fixed, lab_fixed, metric="precomputed")
        for i in set(lab):
            for j in set(lab):
                if i == j or i== -1 or j == -1: 
                    continue
                mean_diams_clusters.append(B[lab==i].T[lab==j].mean())
        diam = max(mean_diams_clusters)        
                
    elif (len(set(lab)) == 1 and list(lab).count(-1) == 0) or (len(set(lab)) == 2 and list(lab).count(-1) > 0):
        sil = -99999
        diam = -99999

    else:
        sil = None
        diam = None

    perc_of_out = list(lab).count(-1)/len(lab)
    sizes_of_clust = [] 
    for i in set(lab):
        if i !=-1:
            sizes_of_clust.append(list(lab).count(i))
    sizes_of_clust = sorted(sizes_of_clust)
    
    if len(sizes_of_clust) > 1:
        ratio = sizes_of_clust[0]/sizes_of_clust[-1]
    else: ratio = 0
    
    ssr_lengths = []
    amount_of_aa_in_prot = np.array(amount_of_aa_in_prot)

    for x in set(lab):
        if x != -1: 
            ssr_lengths.append(np.mean(amount_of_aa_in_prot[lab==x]))

    if list(lab).count(-1) != len(lab):
        num_aa_in_longest_prot = np.max(amount_of_aa_in_prot[lab != -1])
        max_ssr_length = max(ssr_lengths)
    else:
        ssr_lengths.append(np.average(amount_of_aa_in_prot[lab == -1]))
        max_ssr_length = max(ssr_lengths)
        num_aa_in_longest_prot = np.max(amount_of_aa_in_prot)
    
    if list(lab).count(-1) == 0:
        num_of_subf = len(set(lab))
    else:
        num_of_subf = len(set(lab)) - 1    
    
    result = Cluster(dirrss, lab, num_of_cores_intact, sil, nothing, diam, ratio, perc_of_out, align_of_site, max_ssr_length, num_aa_in_longest_prot, list(lab).count(-1), num_of_subf)
    
    return result



        
        
        
        
        
        
        
        
        
        
        
        
